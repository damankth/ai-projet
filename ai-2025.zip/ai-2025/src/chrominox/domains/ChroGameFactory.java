package chrominox.domains;

import java.util.List;

//import chrominox.supervisors.PlayGameSupervisor;



//import chrominox.supervisors.commons.ViewId;

public interface ChroGameFactory {
	//prof
	 void newGame(int playersCount);
	//prof
	ChroGame  getLastGame();// creer la calsse chrogame
	
	ChroGame createGame();

	// pt etre en player 
	ChroGame createPlayers(List<String> nbPlayer);
	//ChroGame createGame(List<String> nbPlayer);
	// methode pour initailisr les nombres de joueurs 
	// methode  pour initialiser si cest une partie classique ou normal
}
