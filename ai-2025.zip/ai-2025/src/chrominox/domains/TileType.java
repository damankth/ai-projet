package chrominox.domains;

/**
 * Un type de tuile représente la couleur que peut contenir une tuile.
 * */
public enum TileType {
	CAMELEON, CYAN, GREEN, MAGENTA, RED, YELLOW;

}
