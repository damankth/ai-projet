package chrominox.supervisors;

import java.util.List;
import java.util.Objects;

import chrominox.domains.*;
import chrominox.supervisors.commons.ViewId;

public class PlayGameSupervisor extends Supervisor {

	private PlayGameView view;
	private ChroGameFactory gameF;
	private ChroGame gameC;

//	public PlayGameSupervisor(ChroGameFactory gameF) {
//		this.gameF= Objects.requireNonNull(gameF);
//		this.gameC= gameF.getLastGame(); 
//		
//		
//	};
	
//	public PlayGameSupervisor(ChroGameFactory factory) {
//		this.gameF=Objects.requireNonNull(factory);
//	}
//	
	public PlayGameSupervisor() {
	//	this.gameF=Objects.requireNonNull(factory);
	}
	public void setView(PlayGameView view) {
		this.view = Objects.requireNonNull(view);
		
		
	}
	
	public ChroGameFactory getGameFactory() {
		if(gameF==null) {
			gameF= new DefaultChroGameFactory();
		}
		return gameF;
	}
	public void createNewGame() {
	 this.gameC = getGameFactory().createGame();
	 if(view!=null) {
		 draw();
	 }
	}
	public void setGame(ChroGame game) {
        this.gameC = Objects.requireNonNull(game);
        if (view != null) {
            draw();
        }
    }
	
	@Override
	public void onEnter(ViewId fromScreen) {
	if(gameC==null) {
		
		 createNewGame();
		
	}
		if (fromScreen == ViewId.MAIN_MENU) {
			
			//TODO: connaître le joueur actif
			
			Player current = gameC.getCurrentPlayer();
			//this.gameC.getCurrentPlayer();
			//TODO: dessiner la main du joueur actif
			//this.gameC.getCurrentPlayer().getMyHand();
			//TODO: dessiner la mosaique
			//this.gameC.createPlateau();
			
			//gameC.createPlateau();
			
		}
	
		draw();
		
	}

	private void draw() {
		view.startDraw();

		drawBoard();
		drawHand();

		view.endDraw();
	}

	private void drawBoard() {
		//TODO: dessiner les tuiles de la mosaique
		//Chromosaic chromosaic = gameC.getChromosaic();
		//Chromino firstChromino = gameC.getFirstChromino();
//		
		//TODO: dessiner le chromino à poser
		//Chromino chromino=this.currentGame.getFirstChromino();
		Chromosaic mosaic = gameC.getChromosaic();
		view.addToBoard(TileType.CYAN.toString(), "BLACK", 0, -1);
		view.addToBoard(TileType.CYAN.toString(), "BLACK", 0, 0);
		view.addToBoard(TileType.CYAN.toString(), "BLACK", 0, 1);

	}

	private void drawHand() {
		//TODO: dessiner les tuiles de la main du joueur actif
		
		
		view.addToHand(TileType.GREEN.toString(), 
				TileType.MAGENTA.toString(), 
				TileType.YELLOW.toString(),
				"black");
		
		
		
		//DefaultChroGameFactory currentGame.newGame(2);
		
		
		
	}

	

	/**
	 * Méthode appelée par la vue pour déplacer le chromino actif sur la mosaique de {@code dr} ligne et de {@code dc} colonnes.
	 * */
	public void onMove(int dr, int dc) {
		//TODO: déplacer la position du chromino actif

		//TODO: rafraichier la vue
	}

	/**
	 * Méthode appelée par la vue pour effectuer une rotation de 90 du chromino actif.
	 * */
	public void onRotate() {
		//TODO: effectuer une rotation de 90° du chromino actif
		
		//TODO: rafraichier la vue
	}

	/**
	 * Méthode appelée par la vue quand le joueur souhaite ajouter son chromino à la mosaique.
	 * */
	public void onConfirm() {
		//TODO: ajouter le chromino sélectionné à la mosaique
		
		//TODO: rafraichier la vue
	}

	/**
	 * Méthode appelée par la vue quand le joueur souhaite passer son tour.
	 * */
	public void onPass() {
		//TODO: gérer le passement de tour.
		
		//TODO: rafraichier la vue
	}


	/**
	 * Appelée par la vue quand le joueur souhaite passer au chromino suivant.
	 * */
	public void onSelectNextPiece() {
		//TODO: passer au chromino suivant
		
		//TODO: rafraichier la vue
	}

	/**
	 * Appelée dans le mode {@code BOARD} si le joueur souhaite changer de pièce.
	 * */
	public void onBack() {
		//TODO: basculer dans le mode HAND
		
		//TODO: rafraichier la vue
	}

	/**
	 * Appelée si le joueur souhaite piocher un nouveau chromino
	 * */
	public void onPick() {
		//TODO: gérer la pioche d'un chromino
		//TODO: rafraichier la vue
	}

	/**
	 * Appelée dans le mode {@code HAND} si le joueur a choisi son chromino.
	 * */
	public void onPieceSelected() {
		//TODO: basculer dans le mode BOARD
		
		//TODO: rafraichier la vue
	}

}
