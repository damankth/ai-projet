package chrominox.supervisors;

import java.util.List;
import java.util.Objects;
import java.util.Set;

import javax.swing.text.html.HTMLDocument.Iterator;

import chrominox.domains.*;
import chrominox.supervisors.commons.ViewId;


public class PlayGameSupervisor extends Supervisor {

	private PlayGameView view;
	private ChroGameFactory gameF;
	private ChroGame gameC;
	private Chromino selectedChromino;
	private int dr;
	private int dc;

//	public PlayGameSupervisor(ChroGameFactory gameF) {
//		this.gameF= Objects.requireNonNull(gameF);
//		this.gameC= gameF.getLastGame(); 
//		
//		
//	};
	
//	public PlayGameSupervisor(ChroGameFactory factory) {
//		this.gameF=Objects.requireNonNull(factory);
//	}
//	
	public PlayGameSupervisor() {
	//	this.gameF=Objects.requireNonNull(factory);
	}
	public void setView(PlayGameView view) {
		this.view = Objects.requireNonNull(view);
		
		
	}
	
	public ChroGameFactory getGameFactory() {
		if(gameF==null) {
			gameF= new DefaultChroGameFactory();
		}
		return gameF;
	}
	public void createNewGame() {
	 this.gameC = getGameFactory().createGame();
	 if(view!=null) {
		 draw();
	 }
	}
	public void setGame(ChroGame game) {
        this.gameC = Objects.requireNonNull(game);
        if (view != null) {
            draw();
        }
    }
	
	@Override
	public void onEnter(ViewId fromScreen) {
	if(gameC==null) {
		
		 createNewGame();
		
	}
		if (fromScreen == ViewId.MAIN_MENU) {
			
			//TODO: connaître le joueur actif
			
			Player current = gameC.getCurrentPlayer();
			//this.gameC.getCurrentPlayer();
			//TODO: dessiner la main du joueur actif
			this.gameC.getCurrentPlayer().getMyHand();
			//TODO: dessiner la mosaique
			this.gameC.createPlateau();
			
			//gameC.createPlateau();
			
		}
	
		draw();
		
	}

	private void draw() {
		view.startDraw();

		drawBoard();
		drawHand();

		view.endDraw();
	}

	private void drawBoard() {
		//TODO: dessiner les tuiles de la mosaique
		//Chromosaic chromosaic = gameC.getChromosaic();
		//Chromino firstChromino = gameC.getFirstChromino();
//		
		//TODO: dessiner le chromino à poser
		//Chromino chromino=this.currentGame.getFirstChromino();
		//Chromino mosaic = gameC.getFirstChromino();
		
//		view.addToBoard(TileType.CYAN.toString(), "BLACK", 0, -1);
//		view.addToBoard(TileType.CYAN.toString(), "BLACK", 0, 0);
//		view.addToBoard(TileType.CYAN.toString(), "BLACK", 0, 1);

		Chromino firstChromino = gameC.getFirstChromino();
		view.addToBoard(firstChromino.getPart1().toString(), "BLACK", 0, -1);
		view.addToBoard(firstChromino.getPart2().toString(), "BLACK", 0, 0);
		view.addToBoard(firstChromino.getPart3().toString(), "BLACK", 0, 1);
	}

	private void drawHand() {
		//TODO: dessiner les tuiles de la main du joueur actif
		
		
//		view.addToHand(TileType.GREEN.toString(), 
//				TileType.MAGENTA.toString(), 
//				TileType.YELLOW.toString(),
//				"black");
//		
		
		Set<Chromino>playersHand= gameC.getCurrentPlayer().getMyHand();
		
//		Iterator<Chromino> hand=  playersHand.iterator();
//		
//		while(hand.hasNext()) {
//			
//			Chromino currentChromino= hand.next();
//			view.addToHand(currentChromino.getPart1().toString(), 
//					currentChromino.getPart2().toString(), 
//					currentChromino.getPart3().toString(),
//					"black");
//			
//		}
		
		for(Chromino chromino :playersHand) {
			view.addToHand(chromino.getPart1().toString(), 
					chromino.getPart2().toString(), 
					chromino.getPart3().toString(),
					"black");
			
		}
			
		
		
		
		
		//DefaultChroGameFactory currentGame.newGame(2);
		
		
		
	}

	

	/**
	 * Méthode appelée par la vue pour déplacer le chromino actif sur la mosaique de {@code dr} ligne et de {@code dc} colonnes.
	 * */
	public void onMove(int dr, int dc) {
		//TODO: déplacer la position du chromino actif
		
		
		view.addToBoard(selectedChromino.getPart1().toString(), "BLACK", 0+dr, -1+dc);
		view.addToBoard(selectedChromino.getPart2().toString(), "BLACK", 0+dr, 0+dc);
		view.addToBoard(selectedChromino.getPart3().toString(), "BLACK", 0+dr, 1+dc);
		
		this.dr=dr;
		this.dc=dc;

		//TODO: rafraichier la vue
		draw();
		
	}
	

	/**
	 * Méthode appelée par la vue pour effectuer une rotation de 90 du chromino actif.
	 * */
	public void onRotate() {
		//TODO: effectuer une rotation de 90° du chromino actif
		
		
		//TODO: rafraichier la vue
	}

	/**
	 * Méthode appelée par la vue quand le joueur souhaite ajouter son chromino à la mosaique.
	 * */
	public void onConfirm() {
		//TODO: ajouter le chromino sélectionné à la mosaique
		
		Coordinate coordinate= new Coordinate(dr, dc);
		//if(gameC.getChromosaic().addChrominoAt(coordinate, selectedChromino))
		gameC.getChromosaic().addChrominoAt(coordinate, selectedChromino);
		
		
				
		
		//TODO: rafraichier la vue
		draw();
	}

	/**
	 * Méthode appelée par la vue quand le joueur souhaite passer son tour.
	 * */
	public void onPass() {
		//TODO: gérer le passement de tour.
		
		
		
		//TODO: rafraichier la vue
		drawHand();
	}


	/**
	 * Appelée par la vue quand le joueur souhaite passer au chromino suivant.
	 * */
	public void onSelectNextPiece() {
		//TODO: passer au chromino suivant
		
		
	

		//TODO: rafraichier la vue
	}

	/**
	 * Appelée dans le mode {@code BOARD} si le joueur souhaite changer de pièce.
	 * */
	public void onBack() {
		//TODO: basculer dans le mode HAND
		
		
		//TODO: rafraichier la vue
		draw();
	}

	/**
	 * Appelée si le joueur souhaite piocher un nouveau chromino
	 * */
	public void onPick() {
		//TODO: gérer la pioche d'un chromino
		//TODO: rafraichier la vue
	}

	/**
	 * Appelée dans le mode {@code HAND} si le joueur a choisi son chromino.
	 * */
	public void onPieceSelected() {
		//TODO: basculer dans le mode BOARD
		
		//TODO: rafraichier la vue
	}

}
