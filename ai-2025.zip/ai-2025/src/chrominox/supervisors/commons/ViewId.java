package chrominox.supervisors.commons;

public enum ViewId {
	MAIN_MENU, PLAY_GAME, NONE, END_GAME
}
