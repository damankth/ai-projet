package chrominox.domains;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;

class DefaultChroGameFactoryTest {

	// faire les test 

	@Test
	void test() {
		fail("Not yet implemented");
	}

}
